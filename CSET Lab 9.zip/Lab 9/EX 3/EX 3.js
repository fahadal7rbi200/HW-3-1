console.log(document.URL);
//OR
document.write(document.URL);
